package orgservelt;

public class UserDefined {

	public String Demo() {
		return "Text from demo method";

	}

}
