package testday5;
import java.io.FileOutputStream;
import java.io.FileReader;
public class IOfile {

	public static void main(String[] args) {
		try {
			FileReader fr=new FileReader("D:\\Ankie.txt");
			int i;
			while((i=fr.read())!=-1)
				System.out.print((char)i);
			//FileOutputStream fp=new FileOutputStream("D:\\Ankie.txt");
			//String s="Welcome to java class";
			//byte b[]=s.getBytes();
			//fp.write(b);
			fr.close();
			//
			}
		catch(Exception e)
		{
			System.out.println(e);
		}
		//System.out.println("Success...");
	}

}
