package testday5;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.ArrayList;

public class TestPro {

	public static void main(String[] args) {
		List<Product> ls=new ArrayList<Product>();
		Product p1=new Product(001,"Lipstick",2000f);
		Product p2=new Product(002,"EyeLiner",1000.90f);
		Product p3=new Product(003,"Lotion",5000f);
		ls.add(p1);
		ls.add(p2);
		ls.add(p3);
		ls.add(new Product(004,"EyeShadow",5000f));
		ls.add(new Product(005,"SunScreen",1100f));
		ls.add(new Product(006,"SunScreen",1100f));
		
		for (Product p:ls) {
			System.out.println("ID:"+p.getId()+" ID:"+p.getName()+
					" Price:"+p.getPrice());
	}
		System.out.println("\n");
		//Price
		List<Float> productprice=new ArrayList<Float>();
		for(Product pro:ls)
		{
			if(pro.price>1000) {
				productprice.add(pro.price);
			}
		}
		System.out.println("Price:"+productprice);
		System.out.println("\n");
		//NAMELIST
		List<String> productname=new ArrayList<String>();
		for(Product pro:ls)
		{
			productname.add(pro.name);
			
		}
		System.out.println("Names:"+productname);
		System.out.println("\n");
		
		//Price
		List<String> productnprice=new ArrayList<String>();
		for(Product pro:ls)
		{
			if(pro.price<1000) {
				productnprice.add(pro.name);
			}
		}
		System.out.println("Name of product:"+productnprice);
		System.out.println("\n");

		//Stream
		List<String>pro2=ls.stream()
				.filter(ls1->ls1.price>1000)
				.map(ls1->ls1.name)
				.collect(Collectors.toList());
		System.out.println("NAmes od product having price > 1000:"+pro2);
System.out.println("\n");
	ls.stream().filter(duct->duct.price==1100)
	.forEach(duct->System.out.println(duct.name));
	
	
	//doubling
		double total=ls.stream().
			collect(Collectors.summingDouble(product->product.price));
	System.out.println("TOtalprice--"+total);
	
	//max
	Product pb=ls.parallelStream()
		.max((product1,product2)->product1.price>product2.price?1:-1).get();
	System.out.println("MAximum Price:"+pb.price);
	
	//min
	
	Product pbmin=ls.stream()
			.max((product1,product2)->product1.price<product2.price?1:-1).get();
		System.out.println("Minimum Price:"+pbmin.price);
		
		//count
		
		long count=ls.stream()
				.filter(product->product.price<5000)
				.count();
		System.out.println("Count:"+count);
		
		//Set
		Set<Float>productprice3=
				ls.stream()
				.filter(product->product.price<5000)
				.map(product->product.price)
				.collect(Collectors.toSet());
		System.out.println("SET:"+productprice3);
		
		//Map
		Map<Integer,String> ppm=ls.stream()
				.collect(Collectors.toMap(p->p.id,p->p.name));
		System.out.println(ppm);
		
		//Methodreference
		List<Float> methref=ls.stream()
				.map(Product::getPrice)
				.collect(Collectors.toList());
	System.out.println(methref);
	}
		
}