package testday5;


interface Messageable{
	Message getMsg(String msg);
}
class Message{
	Message(String msg){
		System.out.println(msg);
	}
}
	public class Testcons {
		
	public static void main(String[] args) {
		Messageable hello=Message::new;
		hello.getMsg("HIIII ANKIE");
	}

}
