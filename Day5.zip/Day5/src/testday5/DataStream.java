package testday5;

import java.io.FileInputStream;
import java.io.FileWriter;

public class DataStream {

	public static void main(String[] args) {
		try {
			FileWriter fw=new FileWriter("D:\\Ankie.txt");
			//FileInputStream fp=new FileInputStream("D:\\Ankie.txt");
			//int i=0;
			//while((i=fp.read())!=-1) {
				//System.out.println((char)i);
		fw.write("Welcome to SLK.This is java class");
		fw.close();
		}
			//fp.close();
		catch(Exception e){System.out.println(e);} {
			System.out.println("Success.....");
		}

	}

}
