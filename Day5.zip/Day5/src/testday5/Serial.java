package testday5;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Serial {

	public static void main(String[] args) {
		try {
			Student s1=new Student(211,"Ankie");
			FileOutputStream fout=new FileOutputStream("D:\\f.txt");
			ObjectOutputStream out=new ObjectOutputStream(fout);
			out.writeObject(s1);
			out.flush();
			out.close();
			System.out.println("Success...");
		}
catch(Exception e) {
	System.out.println(e);
}
	}

}
