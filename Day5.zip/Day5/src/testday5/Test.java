package testday5;

import orgday5.InstanceMethodReference1;
import orgday5.intstat;

public class Test {

	public static void main(String[] args) {
		InstanceMethodReference1 ir=new InstanceMethodReference1();
		intstat sayable=ir::saysomething;
		sayable.say();
		intstat sayable2=new InstanceMethodReference1()::saysomething;
		sayable2.say();
		
}

}
