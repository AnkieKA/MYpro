package orgday5;



	//import testday5.testinstance;

	public class InstanceMethodReference1 {
	public void saysomething()
	{
		System.out.println("THIS is a static method");
	}


	}


