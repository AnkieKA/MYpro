package orgday5;

public interface intstat {
void say();
}
