package org;

public class Person {
	
	public String name;
	public String address;
	public int age;
	
	public void display()
	{
		System.out.println("This is person's info");
		System.out.println("Name:"+name);
		System.out.println("address:"+address);
		System.out.println("age:"+age);
		
		System.out.println("Meet "+name+",hes/she is from "+address+",and is:"+age+" years old");
	}
	

}
