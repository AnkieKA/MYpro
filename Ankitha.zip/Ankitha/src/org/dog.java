package org;

public class dog {
	public String breed;
	public String name;
	public String food;
public void eat()
{
	System.out.println("the breed is:"+breed);
	System.out.println("Name is:"+name);
	System.out.println("Also "+name+" loves to eat"+food);
}

public void sleep()
{
	System.out.println("the " +name+"LOves to sleep");
}
}
