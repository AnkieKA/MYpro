package org;

public class car {
	public String brand;
	public String color;
	public int engine;
	
	public void start()
	{
		System.out.println("WROOM WROOM!!");
	}

}
