package test;

import org.dog;

public class dogmain {

	public static void main(String[] args) {
		dog d1=new dog();
		dog d2=new dog();
		//dog d3=new dog();
		System.out.println("THIS IS MY DOG CLASS");
		d1.breed="GOLDEN RETRIEVER";
		d1.name="OAKY";
		d1.food="PEDIGREE";
		d1.eat();
		d1.sleep();
		
		d2.breed="LABORADOR";
		d2.name="CHANDAN";
		d2.food="CHICKEN";
		d2.eat();
		d2.sleep();

	}

}
