package test;

public class for2 {

	public static void main(String[] args) {
		int i;
		/*for(i=0;i<10;i++)
		{
			System.out.println(i);
		}*/
		for(i=0;i<50;i++)
		{
			if(i%2==0)
				{
				//System.out.println("even");
			System.out.println(i+"--even");
			}
			
			else if(i%2!=0){
				//System.out.println("odd");
				System.out.println(i+"--odd");}
		}
		

	}

}
