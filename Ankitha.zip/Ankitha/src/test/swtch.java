package test;

import java.util.Scanner;

public class swtch {

	public static void main(String[] args) {
		int age;
		String color;
		String sign;
		Scanner scn=new Scanner(System.in);
		System.out.println("enter your age");
		age=scn.nextInt();
		System.out.println("enter your color");
		color=scn.next();
		System.out.println("enter your sign");
		sign=scn.next();
		switch(age)
		{case 18:
			System.out.println("u r adult");
			break;
		case 30:
			System.out.println("u r professional");
			break;
		case 60:
			System.out.println("u r retired");
			break;
		default:
			System.out.println("u r dead");
			break;
		}
		
		switch(color)
		{case "red":
			System.out.println("u r nonveg");
			break;
		case "green":
			System.out.println("u r veg");
			break;
		case "brown":
			System.out.println("u r eggie");
			break;
		default:
			System.out.println("u r dead");
			break;
		}
		int a=10,b=9;
		
		switch(sign)
		{case "+":
			System.out.println("add"+a+b);
			break;
		case "-":
			System.out.println("sub"+(a-b));
			break;
		case "*":
			System.out.println("mul"+a*b);
			break;
		case "/":
			System.out.println("div"+a/b);
			break;
		default:
			System.out.println("cant operate");
			break;
		}

	}

}
