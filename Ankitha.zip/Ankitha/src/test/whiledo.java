package test;

public class whiledo {

	public static void main(String[] args) {
		int i=0;
		System.out.println("while");
		while(i<5)
		{
			System.out.println(i);
			i++;
		}
		System.out.println("do-while");
		do
		{
			System.out.println(i);
			i++;
		}while(i<5);
		

	}

}
