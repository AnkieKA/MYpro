package test;
import org.Person;
import org.car;

public class test {

	public static void main(String[] args) {

Person x1=new Person();
//Person x2=new Person();
System.out.println("this is my test class");
x1.name="TOM";
x1.age=22;
x1.address="GOA";
x1.display();

car c1=new car();
c1.brand="AUDI";
c1.color="black";
c1.start();
/*x2.name="JERRY";
x2.age=24;
x2.address="OOTY";
x2.display();
*/
	}

}
