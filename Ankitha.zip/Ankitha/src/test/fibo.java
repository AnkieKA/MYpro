package test;

public class fibo {

	public static void main(String[] args) {
int num1=0;
int num2=1;
int num3;
int i;
for(i=1;i<=20;++i)
{
	System.out.println(num1);
num3=num1+num2;
num1=num2;
num2=num3;
//System.out.println(num3);
}

	}

}
