package test;

public class greatest {

	public static void main(String[] args) {
		int x=70000000;
		int y=200;
		int z=8000;
		if(x>y&&x>z)
			System.out.println("X IS BIGGER:"+x);
		else if(y>x&&y>z)
			System.out.println("Y IS BIGGER:"+y);
		//else if(z>x&&z>y)
			//System.out.println("Z IS BIGGER:"+z);
		else 
			System.out.println("Z IS BIGGER:"+z);
	}

}
