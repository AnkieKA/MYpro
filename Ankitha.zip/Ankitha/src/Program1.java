
public class Program1 {

	public static void main(String[] args) {
		System.out.println("Hello Class");
		System.out.println("Welcome TO JAVA World");
		System.out.println("All The Best");
		
	}

}
