package org;
import entity.user;
import model.UsersModel;

import java.util.*;
import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class HomeController
 */
@WebServlet("/home")
public class HomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Resource(name = "jdbc/project")
	private DataSource dataSource;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HomeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String page=request.getParameter("page");
		page=page.toLowerCase();
		switch (page) {
		case "home" :
			request.getRequestDispatcher("index.jsp").forward(request, response);
			break;
		case "listusers":
			List<user> listUsers=new ArrayList<>();
			listUsers=new UsersModel().listUsers(dataSource);
			request.setAttribute("listUsers", listUsers);
			request.getRequestDispatcher("listUser.jsp").forward(request, response);
			break;
		
		case "adduserform":
			addUserFormLoader(request, response);
			
		default:
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation=request.getParameter("form");
		operation=operation.toLowerCase();
		switch(operation){
		case "adduseroperation":
			user newUser=new user(request.getParameter("username"),request.getParameter("email"));
			addUserOperation(newUser);
			listUsers(request,response);
			break;
			default :
				request.getRequestDispatcher("error.jsp").forward(request, response);
				break;
		}
		
	}

		private void addUserOperation(user newUser) {
		new UsersModel().addUser(dataSource, newUser);
		return;
		
		}
	
	public void listUsers(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		List<user> listUsers=new ArrayList<>();
		listUsers=new UsersModel().listUsers(dataSource);
		request.setAttribute("listUsers", listUsers);
		request.setAttribute("title","List of users");
		request.getRequestDispatcher("listUser.jsp").forward(request, response);
		
	}

public void addUserFormLoader (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
	request.setAttribute("title", "Add User");
	request.getRequestDispatcher("AddUserForm.jsp").forward(request, response);
}


	}

