package model;
import entity.user;
import java.util.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.activation.DataSource;

import com.mysql.cj.jdbc.PreparedStatement;
public class UsersModel {
public List<user> listUsers(javax.sql.DataSource dataSource){
	List<user> listUsers=new ArrayList<>();
	
	 Connection connect = null;
     Statement stmt = null;
     ResultSet rs = null;
     try {
		connect = dataSource.getConnection();
		
		// Step 2: Create a SQL statements string
		String query = "Select * from users";
		stmt = connect.createStatement();

		// Step 3: Execute SQL query
      rs = stmt.executeQuery(query);
      
		// Step 4: Process the result set
		while(rs.next()){
			listUsers.add(new user(rs.getInt("users_id"), rs.getString("username"), rs.getString("email")));
		}	 			
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     return listUsers;
	
	
	
}

public boolean addUser(javax.sql.DataSource dataSource,user newUser){
	
	  Connection connect = null;
	  PreparedStatement statement=null;
	  try{
		  connect =((Statement) dataSource).getConnection();
		  String username=newUser.getUsername();
		  String email =newUser.getEmail();
		  //String query ="insert into users (username,email) values (?,?)";
		  String query ="insert into users (username,email) values (?,?)";
		  statement =(PreparedStatement) connect.prepareStatement(query);
		  statement.setString(1, username);
		  statement.setString(2, email);
		  return statement.execute();
	  }
	  catch(SQLException e){
		  e.printStackTrace();
		  return false;
		  
	  }
}
}
