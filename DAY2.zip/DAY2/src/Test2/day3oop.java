package Test2;

import inheritance.automobile;
import inheritance.car;
import inheritance.fourwheel;

public class day3oop {

	public static void main(String[] args) {
		//automobile a=new fourwheel("001","black","AUDI","SPORTS");
		//fourwheel f=new car("001","black","AUDI","SPORTS","AUDIAG","100000");
		//car c=new car("001","black","AUDI","SPORTS","AUDIAG","100000");
		//a.display("car","BLACK");
		//a.display("car","RED");
		//f.display("Sportutility","Car");
		//c.display("AUDIAG","100000");
		//System.out.println(a.color);
		//System.out.println(a.engine);
		automobile a=new fourwheel();
		//fourwheel f=new car();
a.start();
a.display("a","b");
//c.run();
	}

}
