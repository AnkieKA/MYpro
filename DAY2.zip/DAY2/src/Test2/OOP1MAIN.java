package Test2;

import java.util.Scanner;

import org2.OOP1;

public class OOP1MAIN {

	public static void main(String[] args) {
		String choice;
		float p,t,r,s1;
		System.out.println("Enter 1 to add:");
		System.out.println("Enter 2 to display name:");
		System.out.println("Enter 3 to find si:");
		System.out.println("Enter 4 to print area:");
		System.out.println("Enter your  choice:");
		Scanner scan=new Scanner(System.in);
		choice=scan.next();
		
		OOP1 o1=new OOP1();
		//o1.sayhi();
	//System.out.println("sayyyyy...."+h);
		//o1.simplei();
		//o1.circle();
		
		switch(choice) {
		case "1":o1.add();
		break;
		case "2":o1.sayhi();
		break;
		case "3":System.out.println("Enter p t and r values:");
		p=scan.nextFloat();
		t=scan.nextFloat();
		r=scan.nextFloat();
		s1=o1.si(p,t,r);
		System.out.println("Simple interest:"+s1);
		break;
		
		/*case "3":float s1=o1.si(1000,10,3);
		System.out.println("Simple interest:"+s1);
		break;*/
		case "4":o1.circle();
		break;
		default:
			System.out.println("PLEASE ENTER VALID CHOICE");
			
		}
		
		//firstname= scan.next();
		
	

	}

}
