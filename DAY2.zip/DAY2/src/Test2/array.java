package Test2;

import java.util.Scanner;

public class array {

	public static void main(String[] args) {
		int m=0;
		int n=0;
		int p=0;
		int q=0;
		int i=0;
		int j=0;
		int k=0;
		int a[][]=new int[10][10];
		int b[][]=new int[10][10];
		int c[][]=new int[10][10];
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the order of A matrix");
		m=scan.nextInt();
		n=scan.nextInt();
		System.out.println("Enter the order of B matrix");
		p=scan.nextInt();
		q=scan.nextInt();
		if(n==p)
		{
		System.out.println("Enter the values of A matrix:");
		for(i=0;i<m;i++)
		{
			for(j=0;j<n;j++)
			{
				a[i][j]=scan.nextInt();
			}
		}
		System.out.println("Matrix A:");
		System.out.println("------------------------");
		for(i=0;i<m;i++)
		{
			for(j=0;j<n;j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println("\n");
		}
		//System.out.println(" ");
		

	
	System.out.println("************************");
	
	System.out.println("Enter the values of B matrix:");
	for(i=0;i<p;i++)
	{
		for(j=0;j<q;j++)
		{
			b[i][j]=scan.nextInt();
		}
	}
	System.out.println("Matrix B:");
	System.out.println("------------------------");
	for(i=0;i<p;i++)
	{
		for(j=0;j<q;j++)
		{
			System.out.print(b[i][j]+" ");
		}
		System.out.println("\n");
	}
	
		System.out.println("\n----Matrix Multiplication----");
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				for(k=0;k<n;k++)
				{
					c[i][j]=c[i][j]+a[i][k]+b[k][j];
				}
			}
		}
		System.out.println("***THE PRODUCT OF TWO Matrices***");
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				System.out.print(c[i][j]+" ");
			}
			System.out.println("\n");
		}
		}
		}
	
	
	
}

