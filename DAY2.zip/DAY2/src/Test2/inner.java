package Test2;

import interfaces.CPU;

public class inner {

	public static void main(String[] args) {
		CPU cpu=new CPU();
		cpu.disp();

	}

}
