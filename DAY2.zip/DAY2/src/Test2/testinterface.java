package Test2;

import interfaces.coffee;
import interfaces.coffeemug;
import interfaces.liquid;
import interfaces.milk;

public class testinterface {

	public static void main(String[] args) {
	 liquid water=new liquid();
	 milk m=new milk();
	 coffee c=new coffee();
	 coffeemug cm=new coffeemug();
	 //liquid li;
	cm.add(water);

	}

}
