package Test2;

import java.util.Scanner;

import org2.Overload;

public class Overloadmain {

	public static void main(String[] args) {
		Overload o1=new Overload();
		int x,y;
		float z;
		Scanner scan=new Scanner(System.in);
		System.out.println("enter x,y,z");
		x=scan.nextInt();
		y=scan.nextInt();
		z=scan.nextFloat();
		System.out.println(o1.sum(x,y));
		System.out.println(o1.sum(x,y,z));
		System.out.println(o1.sum(x,y));
		
		
		

	}

}
