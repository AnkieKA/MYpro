package Test2;

import inheritance.Shape;
import inheritance.circel;
import inheritance.rec;
import inheritance.tri;

public class test {

	public static void main(String[] args) {

		Shape s= new Shape();
		circel c=new circel();
		tri t= new tri();
		rec r=new rec();
		s.dis();
		c.area();
		t.area();
		r.area();
		

	}

}
