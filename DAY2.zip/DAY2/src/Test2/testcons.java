package Test2;

import inheritance.livingthing;
import inheritance.plant;
import inheritance.rose;

public class testcons {

	public static void main(String[] args) {
		livingthing x=new livingthing();
		livingthing l=new plant(1,"l",7,"k");
		l.eat();
		plant p=new rose();
		p.eat();
		

	}

}
