package inheritance;

public class rose extends plant{
	
	public String fragnance;
	public rose() {}
	public rose(int h,String c,int a,String t,String f)
	{
		super(h,c,a,t);
		f=fragnance;
		System.out.println("This is rose constructor");
	}
	public void eat()
	{
		System.out.println("ROSE eats oxy");
	}

}
