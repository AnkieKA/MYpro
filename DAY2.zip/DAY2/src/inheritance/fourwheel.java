package inheritance;

public class fourwheel extends automobile{
public String brand;
public String type;
//public abstract void run();
public void display()
{
	System.out.println("FOURWHEELER");

	System.out.println("TYPE="+type);
	System.out.println("BRAND="+brand);
}
public fourwheel() {}
public fourwheel(String e,String c,String b,String t)
{
super(e,c);
b=brand;
t=type;
	
	System.out.println("THIS IS FOURWHEELER CONSTRUCTOR");
}
@Override
public void start() {
	System.out.println("FOURWHEELER starts");
	
}
}
