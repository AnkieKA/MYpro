package inheritance;

public class tri extends Shape {
	public void area()
	{
		float b = 0,h=0;
		area=0.5*b*h;
		System.out.println("tri:"+area);
		System.out.println("COLOR:red");
			}

}
