package inheritance;

public class jasmine extends plant{
		
		public String fragnance;
		public jasmine() {}
		public jasmine(int h,String c,int a,String t,String f)
		{
			super(h,c,a,t);
			f=fragnance;
			System.out.println("This is jas constructor");
		}
		public void eat()
		{
			System.out.println("ROSE jas oxy");
		}

	}


