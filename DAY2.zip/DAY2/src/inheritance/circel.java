package inheritance;

public class circel extends Shape{
	public void area()
	{
		float r=3;
		area=3.14f*r*r;
		System.out.println(area);
		System.out.println("COLOR:green");
	}

}
