package inheritance;

public class plant extends livingthing{
	public String type;
	public plant()
	{}
	public plant(int h,String c,int a,String t)
	{
		super(h,c,a);
		type=t;
		System.out.println("This is constructor");
	}
	public void eat()
	{
		System.out.println("PLANTS eats oxygen");
	}
}
