package inheritance;

public abstract class automobile {
	public String engine;
	public String color;
	public abstract void start();
	public final String comp="slk";

	public automobile() {}
	public void display(String engine,String color)
	{
		System.out.println("NAME OF THE ENGINE="+engine);
		System.out.println("COLORS="+color);
		//anceomp="TCS";
		System.out.println(comp);
	}
	
	public automobile(String e,String c)
	{
		System.out.println("THIS IS AUTOMOBILE CONSTRUCTOR");
	}

}
 