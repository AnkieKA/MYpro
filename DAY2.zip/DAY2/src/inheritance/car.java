package inheritance;

public class car extends fourwheel{
public String name;
public String price;

public void display(String name,String color)
{
	System.out.println("NAME of the car="+name);
	System.out.println("COLORS="+color);
}

public car(String e,String c,String b,String t,String n,String p)
{
	super(e,c,b,t);
	n=name;
	p=price;
	System.out.println("THIS Is car CONSTRUCTOR");
}


/*public void run() {

	System.out.println("CAr runs!!");
	
}*/

}
