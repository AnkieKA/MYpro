package inheritance;

public class Shape {

	public double area;
	public String color;
	public void dis()
	{
		System.out.println("color!!!");
	}
	
	

}
