package inheritance;

public class livingthing {

	public int height;
	public int age;
	public String color;
	
	public livingthing()
	{
		System.out.println("THIS IS LIVING THING");
	}
	
	public livingthing(int h,String c,int a)
	{
		height=h;
		color=c;
		age=a;
		System.out.println("This is constructor");
	}
	public void eat()
	{
		System.out.println("LIVING eats food");
	}
	
}