package inheritance;

public class rec extends Shape{
	public void area()
	{
		float b = 0,h=0;
		area=b*h;
		System.out.println("rec:"+area);
		System.out.println("COLOR:blue");
			}

}
