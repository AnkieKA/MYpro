package org2;

import java.util.Scanner;

public class OOP1 {

public void add()
{
	int a,b,c;
	Scanner scan=new Scanner(System.in);
	System.out.println("enter values:");
	a=scan.nextInt();
	b=scan.nextInt();
	c=a+b;
	System.out.println("addition:"+c);
}
	
public void simplei()
{
	float p=10,t=2,r=3;
	float si=(p*t*r)/100;
	System.out.println("Simple interest="+si);
}

public void circle()
{
	float r=20;
	double area=3.14*r*r;
	System.out.println("aea of circle="+area);
}

public void sayhi()
{
	String firstname,lastname;
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter your  first name:");
	firstname= scan.next();
	System.out.println("Enter your  last name:");
	lastname= scan.next();
	System.out.println("hello "+firstname+" "+lastname);
	//turn "HIIII!";
}

public float si(float p,float t,float r)
{
float s;
s=(p*t*r)/100;
return s;
}
}

