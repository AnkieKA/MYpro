package org2;

public class Overload {

	public int sum(int x,int y)
	{
		return (x+y);
	}
	
	public float sum(int x,float y)
	{
		return (x+y);
	}
	public float sum(float x,int y)
	{
		return (x+y);
			}
	public int sum(int x,int y,int z)
	{
		return (x+y+z);
			}
	public float sum(int x,int y,float z)
	{
		return (x+y+z);
			}
}
