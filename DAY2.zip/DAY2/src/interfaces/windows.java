package interfaces;

public class windows implements washable {
	public void wash()
	{
		System.out.println("WASH UR WINDOWS!");
	}

}
