package interfaces;

public class CPU {
private class Motherboard
{
	public void comp()
	{
		System.out.println("Motherboard will be in CPU");
		System.out.println("There are many components in the motherboard");
	}
	public void cost()
	{
		System.out.println("Also,Motherboard costs 10000");
	}
}
public void disp()
{
	Motherboard mb=new Motherboard();
	mb.comp();
	mb.cost();
}
}
