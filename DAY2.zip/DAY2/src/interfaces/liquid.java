package interfaces;

public class liquid {
public void swirl()
{System.out.println("SWIRLLLLL!!!");
}
}
