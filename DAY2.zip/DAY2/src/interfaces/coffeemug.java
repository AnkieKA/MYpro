package interfaces;

public class coffeemug implements washable{
public void wash()
{
	System.out.println("YOU ARE WASHING MUG");
}
public void add(liquid li)
{
	if(li instanceof milk)
	{
		li.swirl();
		System.out.println("YOU GOT MILK");
	}else if(li instanceof coffee)
	{
		li.swirl();
		System.out.println("U GOT COFFEE");
	}
	else
		System.out.println("U GOT WATER");
}
}
