package interfaces;

public class milk extends liquid{
public void swirl()
{
	System.out.println("SWIRLING MILK");
}
}
