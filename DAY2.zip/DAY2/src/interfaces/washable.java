package interfaces;

public interface washable {
public void wash();
}
