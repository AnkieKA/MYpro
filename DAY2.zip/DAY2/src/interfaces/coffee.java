package interfaces;

public class coffee extends liquid{
	public void swirl()
	{System.out.println("SWIRLING COFFEE!!!");
	}
}
