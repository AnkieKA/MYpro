package TestBAnk;

import java.sql.SQLException;
import java.util.List;

public interface CustomerDao {
	public void viewProfile(String cust_uname) throws SQLException;
	List<Customer> viewAllCustomer();
	public void checkBalance(String cust_uname);
//Loan viewLoan(Long customer_balance);
//List<transaction> transactionHistory(int customer_id;)
	public void transfer(String cust_uname,String cust_pass,int amt,int acc_no);
	public void mini_stat (String cust_uname);
}

