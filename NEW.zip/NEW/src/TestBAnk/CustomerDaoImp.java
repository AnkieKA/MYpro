package TestBAnk;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
//import java.util.List;
import java.util.List;
//import java.util.Scanner;

public class CustomerDaoImp implements CustomerDao {
	static Connection con = null;

	private static Connection getConnection() throws SQLException {
		Connection conn;
		conn = ConnectionFactory.getInstance().getConnection();
		return conn;
	}

	public void viewProfile(String cust_uname) throws SQLException

	{
		// String cnme=null;
		// cnme=cust_uname;
		con = getConnection();
		Statement st = (Statement) con.createStatement();
		String query = "select * from customer where customer_username='" + cust_uname + "';";
		ResultSet rs = ((java.sql.Statement) st).executeQuery(query);
		rs.next();
		System.out.println(rs.getString("customer_id"));
		System.out.println(rs.getString("customer_ac_no"));
		System.out.println(rs.getString("customer_balance"));
		System.out.println(rs.getString("customer_name"));
		System.out.println(rs.getString("customer_dob"));
		System.out.println(rs.getString("customer_email"));
		System.out.println(rs.getString("customer_phone"));
		System.out.println(rs.getString("customer_adhar"));
		System.out.println(rs.getString("customer_pan"));
		System.out.println(rs.getString("customer_loan"));
		System.out.println(rs.getString("customer_branch_ifsc"));
		System.out.println(rs.getString("customer_ac_type"));

	}

	public List<Customer> viewAllCustomer() {
		List<Customer> lc = new ArrayList<Customer>();
		try {
			
			con = getConnection();
			Statement st1 = (Statement) con.createStatement();
			String query1 = "select * from customer;";
			ResultSet rs = ((java.sql.Statement) st1).executeQuery(query1);

			while (rs.next()) {
				String cid = rs.getString(1);
				int canum = rs.getInt(2);
				long bal = rs.getLong(3);
				String name = rs.getString(4);
				String date = rs.getString(5);
				String email = rs.getString(6);
				long phone = rs.getLong(7);
				long adhar = rs.getLong(8);
				String pan = rs.getString(9);
				String cun = rs.getString(10);
				String cpass = rs.getString(11);
				String loan = rs.getString(12);
				String branch = rs.getString(13);
				String actype = rs.getString(14);
				lc.add(new Customer(cid, canum, bal, name, date, email, phone, adhar, pan, cun, cpass, loan, branch,
						actype));
			}
			lc.stream().forEach(Customer -> System.out.println(Customer.getCustomer_id()+"||"+Customer.getCustomer_ac_no()+
					"||"+Customer.getCustomer_balance()+"||"+Customer.getCustomer_name()+"||"+Customer.getCustomer_dob()+"||"+
					Customer.getCustomer_email()+"||"+Customer.getCustomer_phone()+"||"+Customer.getCustomer_adhar()+"||"+
					Customer.getCustomer_pan()+"||"+Customer.getCustomer_username()+"||"+Customer.getCustomer_password()+"||"
					+Customer.getCustomer_loan()+"||"+Customer.getCustomer_branch_ifsc()+"||"+Customer.getCustomer_ac_type()));
			con.close();
		} catch (Exception e) {
			
			System.out.println(e);
		}
		return lc;
		
	}
	
	public void checkBalance(String cust_uname) 

	{
try {
		con = getConnection();
		Statement st = (Statement) con.createStatement();
		String query = "select customer_balance from customer where customer_username='" + cust_uname + "';";
		ResultSet rs = ((java.sql.Statement) st).executeQuery(query);
		rs.next();
		System.out.println(rs.getString("customer_balance"));
}
catch(Exception e) {System.out.println(e);}

	}

//transfer
	public void transfer(String cust_uname,String cust_pass,int amt,int acc_no)
	{
		try
		{
		con=getConnection();
		String query="select customer_balance from customer where customer_username='"+cust_uname+"' and customer_password='"+cust_pass+"'";
		Statement st=(Statement) con.createStatement();
		ResultSet rs=st.executeQuery(query);
		rs.next();
		int balance=rs.getInt(1);
		if(balance>amt) {
		int bal=balance-amt;
		
		//System.out.println("testttttttttttt");
		
		
		String query1="update customer set customer_balance="+bal+" where customer_username='"+cust_uname+"'";
		Statement st1=(Statement) con.createStatement();
		st1.executeUpdate(query1);
		
		String query3="select customer_balance from customer where customer_ac_no="+acc_no+"";
		Statement st3=(Statement) con.createStatement();
		ResultSet rs3=st3.executeQuery(query3);
		rs3.next();
		int balance1=rs3.getInt(1);		
		int bal1=balance1+amt;
		System.out.println(bal1);

		String query2="update customer set customer_balance="+bal1+" where customer_ac_no="+acc_no+"";
		//Statement st2=(Statement) con.createStatement();
		st.executeUpdate(query2);
		//System.out.println("Balance="+rs.getInt("balance"));
		System.out.println("Successfully tranferred");
		
		
		//Update
		String query4 ="select max(trans_id) from transcation;";
		Statement st4=(Statement) con.createStatement();
		ResultSet rs4=st4.executeQuery(query4);
		
		String query5="select customer_ac_no from customer where customer_username='"+cust_uname+"'";
		Statement st5=(Statement) con.createStatement();
		ResultSet rs5=st5.executeQuery(query5);
		rs5.next();
		int s_ac=rs5.getInt(1);
		
		//debit
		int temp;
		rs4.next();
		temp=rs4.getInt(1);
		int t_id=temp+1;
		
		//Date
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDate localDate = LocalDate.now();
		String t_d=dtf.format(localDate);
		//debit
		//String insertSt="Insert into transcation values("+t_id+",'"+t_d+"',++,"+amt+","+s_ac+")";
		String insertSt="insert into transcation(trans_id,trans_date,debit,customer_ac_no)values("+t_id+",'"+t_d+"',"+amt+","+s_ac+")";
		Statement st6=(Statement) con.createStatement();
		st6.executeUpdate(insertSt);
		System.out.println("Record inserted inTransaction table.......");
		
		//credit
		
		/*int temp1;
		rs4.next();
		temp1=rs4.getInt(1);*/
		t_id++;
		
		String insertSt1="insert into transcation(trans_id,trans_date,credit,customer_ac_no)values("+t_id+",'"+t_d+"',"+amt+","+acc_no+")";
		Statement st7=(Statement) con.createStatement();
		st7.executeUpdate(insertSt1);
		System.out.println("Record-2 inserted inTransaction table.......");
		
		
		}else {System.out.println("Insufficient funds");}
		}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
		
		public void mini_stat(String cust_uname)
		{
			try
			{
				con = getConnection();
				Statement st8 = (Statement) con.createStatement();
				String query8="select customer_ac_no from customer where customer_username='"+cust_uname+"'";
				//Statement st8=(Statement) con.createStatement();
				ResultSet rs8=st8.executeQuery(query8);
				rs8.next();
				int s_ac1=rs8.getInt(1);
				
				Statement st9 = (Statement) con.createStatement();
				String query9="select * from transcation where customer_ac_no='"+s_ac1+"'";
				ResultSet rs9=st9.executeQuery(query9);
				System.out.println("Your Mini Statement");
				while(rs9.next())
				{
				System.out.println(rs9.getInt("trans_id"));
				System.out.println(rs9.getString("trans_date"));
				System.out.println(rs9.getFloat("credit"));
				System.out.println(rs9.getFloat("debit"));
				System.out.println(rs9.getInt("customer_ac_no"));
				System.out.println("");
				System.out.println("");
				}
				
			}catch(Exception e) {System.out.println(e);}
			
		}
		
	}


	
	
	



