package TestBAnk;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	String url="jdbc:mysql://localhost:3306/swissbank?useSSL=false";
	String uname="root";
	String pass="1234";
	String driverClassName="com.mysql.cj.jdbc.Driver";
	
	private static ConnectionFactory connectionFactory=null;
	
	private ConnectionFactory()
	{
		try {
			Class.forName(driverClassName);
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() throws SQLException
	{
		Connection conn=null;
		conn=DriverManager.getConnection(url,uname,pass);
		return conn;
	}

	public static ConnectionFactory getInstance() {
		if(connectionFactory==null)
		{
			connectionFactory=new ConnectionFactory();
		}
		return connectionFactory;
		}
	}




