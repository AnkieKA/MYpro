package TestBAnk;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class SwissTest {
	
	static Connection con = null;

	private static Connection getConnection() throws SQLException {
		Connection conn;
		conn = ConnectionFactory.getInstance().getConnection();
		return conn;
	}

	public static void main(String[] args) throws Exception {
		CustomerDaoImp cdaoimp=new CustomerDaoImp();

		//String customer_username = null;
		//String customer_password = null;

		System.out.println("                             ***************************** ");
		System.out.println("                             ************     ************ ");
		System.out.println("                             ************     ************ ");
		System.out.println("                             ************     ************ ");
		System.out.println("                             ************     ************ ");

		System.out.println("                             *****                   ***** ");
		System.out.println("                             *****     SWISS BANK    ***** ");
		System.out.println("                             *****                   ***** ");

		System.out.println("                             ************     ************ ");
		System.out.println("                             ************     ************ ");
		System.out.println("                             ************     ************ ");
		System.out.println("                             ************     ************ ");
		System.out.println("                             *****************************");
		System.out.println(" ");

		System.out.println("........................................................................................ ");
		System.out.println("........................................................................................ ");
		System.out.println("........................................................................................ ");
		System.out.println("---------------------------------Swiss Bank Corporation--------------------------------- ");
		System.out.println("........................................................................................ ");
		System.out.println("........................................................................................ ");
		System.out.println("........................................................................................ ");

		// System.out.println("**********----------**********SWISS
		// BANK**********----------**********");
		System.out.println("-----------------------------------------WELCOME-----------------------------------------");
		System.out.println("\n");
		// System.out.println("Welcome!!");

		System.out.println("PLEASE ENTER YOUR CHOICE");
		System.out.println("1.Press 1 to User Login");
		System.out.println("2.Press 2 to Admin Login");
		System.out.println("3.Press 3 to EXIT");
		Scanner scan = new Scanner(System.in);
		int c = scan.nextInt();
		switch (c) {

		case 1:
			con = getConnection();
			Statement st = (Statement) con.createStatement();
			System.out.println("Enter the UserName:");
			String cust_uname = scan.next();
			System.out.println("Enter the Password:");
			String cust_pass = scan.next();
			String query = "select customer_username,customer_password from customer where customer_username='"
					+ cust_uname + "'and customer_password='" + cust_pass + "';";
			
			ResultSet rs = ((java.sql.Statement) st).executeQuery(query);
			rs.next();
			
			
			//cust_uname = rs.getString("customer_username");
			//cust_pass = rs.getString("customer_password");
			// check user
			if ((rs.getString("customer_username")).equals(cust_uname)
					&& (rs.getString("customer_password")).equals(cust_pass)) {
				System.out.println("**********User Authentication success**********");
				System.out.println("");

				// user options
				System.out.println("                            1. View Profile");
				System.out.println("                            2. Update Profile");
				System.out.println("                            3. Check Balance");
				System.out.println("                            4. Withdraw");
				System.out.println("                            5. Deposit");
				System.out.println("                            6. Mini-statememnt");
				System.out.println("                            7. Transfer");
				System.out.println("                            8. Create Account");
				System.out.println("                            9. Delete Account");
				System.out.println("                            10. Exit Account");
				System.out.println("****************************Enter the choice");

				int c1;
				c1 = scan.nextInt();
				switch (c1) {
				case 1:
					
					cdaoimp.viewProfile(cust_uname);
					//System.out.println("1");
					//break; // optional

				case 2:
					System.out.println("2");
					break; // optional

				case 3:
					cdaoimp.checkBalance(cust_uname);
					//System.out.println("3");
					break; // optional

				case 4:
					System.out.println("4");
					break; // optional

				case 5:
					System.out.println("5");
					break; // optional

				case 6:cdaoimp.mini_stat (cust_uname);
					//System.out.println("6");
					break; // optional

				case 7:System.out.println("Enter the amount to be transferred");
						int amt=scan.nextInt();
						System.out.println("Enter the acc_no of the reciever");
						int acc_no=scan.nextInt();
				
					cdaoimp.transfer(cust_uname,cust_pass,amt,acc_no);
					//System.out.println("7");
					break; // optional

				case 8:
					System.out.println("8");
					break; // optional

				case 9:
					System.out.println("9");
					break; // optional
					
				case 10:
					System.out.println("10");
					break; // optional

				default:
					System.out.println("Enter the correct Choice");

				}
				// System.out.println("**************testing*********");
			} else {
				System.out.println("Incorrect credentials");
			}

			break;

		// Admin option
		case 2:
			con = getConnection();
			Statement st1 = (Statement) con.createStatement();
			System.out.println("Enter the AdminName:");
			String Ad_uname = scan.next();
			System.out.println("Enter the Password:");
			String Ad_pass = scan.next();
			String query1 = "select admin_username,admin_password from admin where admin_username='" + Ad_uname
					+ "'and admin_password='" + Ad_pass + "';";
			ResultSet rs1 = ((java.sql.Statement) st1).executeQuery(query1);
			rs1.next();
			Ad_uname = rs1.getString("admin_username");
			Ad_pass = rs1.getString("admin_password");
			// check user
			if ((rs1.getString("admin_username")).equals(Ad_uname)
					&& (rs1.getString("admin_password")).equals(Ad_pass)) {
				System.out.println("Admin Authentication success");
				System.out.println("");

				System.out.println("                            1. View All Accounts");
				System.out.println("                            2. Remove Accounts");
				System.out.println("                            3. View All Transactions");
				System.out.println("                            4. Search By Account");
				System.out.println("                            5. Exit");

				System.out.println("                            Enter the choice");
				int c2;
				c2 = scan.nextInt();
				switch (c2) {
				case 1:
					cdaoimp.viewAllCustomer();
					//System.out.println("1");
					break; // optional

				case 2:
					System.out.println("2");
					break; // optional

				case 3:
					System.out.println("3");
					break; // optional

				case 4:
					System.out.println("4");
					break; // optional

				case 5:
					System.out.println("5");
					break; // optional
				default:
					System.out.println("Enter the correct Choice");

				}

			} else {
				System.out.println("Incorrect credentials");
			}
			break;
		default:
		}

	}

}
